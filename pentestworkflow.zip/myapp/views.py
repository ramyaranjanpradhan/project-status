from django.shortcuts import render

# Create your views here.
from .models import masterdb
from .forms import UserForm
from pandas import DataFrame
from io import BytesIO
from django.contrib.auth import get_user_model
from django.http import JsonResponse, HttpResponse
from django.views.generic import View
from django.shortcuts import render
from io import BytesIO
import xlsxwriter
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, get_object_or_404, redirect, reverse
from django.contrib.auth.decorators import login_required

@login_required
def home(request):
    # if not request.user.is_authenticated:
    #     return redirect('%s?next=%s' % (settings.LOGIN_URL, request.path))
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            pass  # does nothing, just trigger the validation
    else:
        form = UserForm()
    return render(request, 'myapp/addpentest.html', {'form': form})

@login_required
def current_status(request):
    masterdata = masterdb.objects.order_by('serialNo')
    return render(request,'myapp/pentest_list.html', {'masterdata': masterdata})

@login_required
def download_data(request):
    # serialNo=masterdb.objects.raw('SELECT serialNo from myapp_masterdb')
    # sysid=masterdb.objects.raw('SELECT sysid from myapp_masterdb')
    # appname=masterdb.objects.raw('SELECT appname from myapp_masterdb')
    # appstartdate=masterdb.objects.raw('SELECT appstartdate from myapp_masterdb')
    # actualenddate=masterdb.objects.raw('SELECT actualenddate from myapp_masterdb')
    # tester=masterdb.objects.raw('SELECT tester from myapp_masterdb')
    # output = BytesIO()
    # datas={'Serial Number':serialNo,'SYS ID':masterdb,'Application Name':appname,'Application Start Date':appstartdate,
    #         'Application End Date ':actualenddate,'Name of Tester':tester}
    # df = DataFrame(datas, columns= ['Serial Number', 'SYS ID','Application Name','Application Start Date','Application End Date','Name of Tester'])
    # export_excel = df.to_excel ('export_dataframe.xlsx', index = None, header=True)
    # output.seek(0)
    # response = HttpResponse(output.read(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    # return response
    output = BytesIO()
        # Feed a buffer to workbook
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet("2020_PenTest_Data")
    datas = masterdb.objects.all()
    bold = workbook.add_format({'bold': True})
    columns= ['Serial Number', 'SYS ID','Application Name','Application Start Date','Application End Date','Name of Tester']
    row = 0
    for i,elem in enumerate(columns):
        worksheet.write(row, i, elem, bold)
    row += 1
    for data in datas:
        print(data.appstartdate)
        print(data.actualenddate)
        worksheet.write(row, 0, data.serialNo)
        worksheet.write(row, 1, data.sysid)
        worksheet.write(row, 2, data.appname)
        worksheet.write(row, 3, data.appstartdate)
        worksheet.write(row, 4, data.actualenddate)
        worksheet.write(row, 5, data.tester)
        row += 1
    workbook.close()
    output.seek(0)
    response = HttpResponse(output.read(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    return response
# def user_login(request):
#     context = {}
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user:
#             login(request, user)
#             masterdata = masterdb.objects.order_by('serialNo')
#             return render(request, 'myapp/pentest_list.html', {'masterdata': masterdata})
#         else:
#             context['error'] = "Provide valid credentials"
#             return render(request, 'myapp/login.html', context)
#     else:
#         return render(request, 'myapp/login.html', context)
# def user_logout(request):
#     if request.method == 'POST':
#         logout(request)
#         return render(request, 'myapp/login.html', context)
#     return redirect('login')


# reverse('user_login')
