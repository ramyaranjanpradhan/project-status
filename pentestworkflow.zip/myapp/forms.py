from django import forms
from django.forms import ValidationError
from django.contrib.auth.models import User
from .models import masterdb

class UserForm(forms.ModelForm):
    serialNo=forms.IntegerField(label='Enter Serial Number of the Application')
    sysid=forms.CharField(max_length=3, label='Enter SYS ID of the application')
    appname=forms.CharField(max_length=100, label='Enter Name of the application')
    appstartdate=forms.DateField(label='Enter Start Date of the Application Testing')
    actualenddate=forms.DateField(input_formats=['%m/%d/%Y'],label='Enter End Date of the Application Testing')
    tester=forms.CharField(max_length=100, label='Enter Name of the Tester')

    def clean(self):
        cleaned_data = super(UserForm, self).clean()
        serialNo = cleaned_data.get('serialNo')
        sysid = cleaned_data.get('sysid')
        appname = cleaned_data.get('appname')
        appstartdate=cleaned_data.get('appstartdate')
        actualenddate=cleaned_data.get('actualenddate')
        tester=cleaned_data.get('tester')
        if not serialNo and not sysid and not appname and not appstartdate and not actualenddate and not tester:
            raise forms.ValidationError('You have to write something!')

    class Meta(object):
        """docstring for Meta."""
        model=masterdb
        fields=['serialNo','sysid','appname','appstartdate','actualenddate','tester']
