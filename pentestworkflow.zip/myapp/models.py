from django.db import models

# Create your models here.
class masterdb(models.Model):
    """docstring for ."""
    serialNo=models.IntegerField()
    sysid=models.CharField(max_length=3)
    appname=models.CharField(max_length=100)
    appstartdate=models.DateField()
    actualenddate=models.DateField()
    tester=models.CharField(max_length=100)
