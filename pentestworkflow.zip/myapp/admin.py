from django.contrib import admin
from .models import masterdb

admin.site.register(masterdb)
# Register your models here.
